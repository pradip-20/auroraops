package com.virtusa.auroraops.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.auroraops.dto.OrderResponse;
//import com.virtusa.auroraops.models.OrderResponse;
import com.virtusa.auroraops.models.SegmentMasterModel;
@Repository
public interface SegmentMasterRepository extends JpaRepository<SegmentMasterModel,Integer>{

	
	/*@Query(value="select com.virtusa.auroraops.dto.OrderResponse(s.Segment_Value,r.Program_Name,p.GDPR,c.Process_Template, q.Area,l.Revenue,l.Cost) from SegmentMaster s inner join ProjectMaster p on\r\n" + 
			"s.Aurora_Segment_Seq=p.Aurora_Segment_Seq_fk_int inner join ProgramMaster r on\r\n" + 
			"p.Aurora_Program_Seq_fk=r.Aurora_Program_Seq  inner join ChorusMaster c  on\r\n" + 
			"p. Aurora_Project_Seq=c.Aurora_Project_Seq_fk_int inner join SowMaster q on\r\n" + 
			"q.Aurora_SOW_Seq=p.Aurora_SOW_Seq_fk_int inner join ProjectLeadMaster l on\r\n" + 
			"c.Chorus_Code=l.Course_Code_fk;",nativeQuery=true)*/
	
	@Query(value="select new com.virtusa.auroraops.dto.OrderResponse(s.Segment_Value,r.Program_Name,p.GDPR,c.Process_Template,q.Area,l.Revenue,l.Cost) from SegmentMaster s inner join ProjectMaster p on s.Aurora_Segment_Seq=p.Aurora_Segment_Seq_fk_int inner join ProgramMaster r on p.Aurora_Program_Seq_fk=r.Aurora_Program_Seq  inner join ChorusMaster c  on p. Aurora_Project_Seq=c.Aurora_Project_Seq_fk_int inner join SowMaster q on q.Aurora_SOW_Seq=p.Aurora_SOW_Seq_fk_int inner join ProjectLeadMaster l on c.Chorus_Code=l.Course_Code_fk",nativeQuery=true) 
	
	//@Query(value="select s.Segment_Value,r.Program_Name,p.GDPR,c.Process_Template, q.Area,l.Revenue,l.Cost from SegmentMaster s inner join ProjectMaster p on s.Aurora_Segment_Seq=p.Aurora_Segment_Seq_fk_int inner join ProgramMaster r on p.Aurora_Program_Seq_fk=r.Aurora_Program_Seq  inner join ChorusMaster c on p. Aurora_Project_Seq=c.Aurora_Project_Seq_fk_int inner join SowMaster q on q.Aurora_SOW_Seq=p.Aurora_SOW_Seq_fk_int inner join ProjectLeadMaster l on c.Chorus_Code=l.Course_Code_fk;",nativeQuery=true)
	
/*@Query(value="select Segment_Value,Program_Name, GDPR,Process_Template ,Area,Revenue,Cost from(select s.Segment_Value,r.Program_Name,p.GDPR,c.Process_Template, q.Area,l.Revenue,l.Cost from SegmentMaster s inner join ProjectMaster p on\r\n" + 
		"			s.Aurora_Segment_Seq=p.Aurora_Segment_Seq_fk_int inner join ProgramMaster r on\r\n" + 
		"			p.Aurora_Program_Seq_fk=r.Aurora_Program_Seq  inner join ChorusMaster c  on \r\n" + 
		"			p. Aurora_Project_Seq=c.Aurora_Project_Seq_fk_int inner join SowMaster q on \r\n" + 
		"			q.Aurora_SOW_Seq=p.Aurora_SOW_Seq_fk_int inner join ProjectLeadMaster l on \r\n" + 
		"			c.Chorus_Code=l.Course_Code_fk) as q1;",nativeQuery=true)*/
	public List<OrderResponse> getJoinInformation();
}
