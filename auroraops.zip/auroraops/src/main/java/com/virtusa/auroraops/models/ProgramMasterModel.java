package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ProgramMaster")
public class ProgramMasterModel {
	
	@Id
	@Column(name = "Program_Id",nullable = false)
	private int Program_Id;
	
	@Column(name = "Program_Name",columnDefinition="char(30)",nullable = false)
	private String Program_Name;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="program_id_fk_int",referencedColumnName="Program_Id")
	List<ProjectMasterModel> pmodel = new ArrayList<>();
	//List<SowMasterModel> smodel = new ArrayList<>();
	
	public ProgramMasterModel() {
		
	}
	

	
	public ProgramMasterModel(int program_Id, String program_Name) {
		super();
		Program_Id = program_Id;
		Program_Name = program_Name;
	}



	public int getProgram_Id() {
		return Program_Id;
	}

	public void setProgram_Id(int program_Id) {
		Program_Id = program_Id;
	}

	public String getProgram_Name() {
		return Program_Name;
	}

	public void setProgram_Name(String program_Name) {
		Program_Name = program_Name;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}
	
	
	

}
