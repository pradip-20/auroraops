package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="CitiEntityMaster")
public class CitiLegalEntityModel {
	@Id
	@Column(name = "Citi_Legal_Entity_Id",nullable = false)
	private int Citi_Legal_Entity_Id;
	
	@Column(name = "Citi_Legal_Entity_Value",columnDefinition="char(30)",nullable = false)
	private String Citi_Legal_Entity_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Citi_Legal_Entity_Id_fk_int",referencedColumnName="Citi_Legal_Entity_Id")
	List<SowMasterModel> smodel = new ArrayList<>();
	
	public CitiLegalEntityModel() {
		
	}
	

	public CitiLegalEntityModel(int citi_Legal_Entity_Id, String citi_Legal_Entity_Value) {
		super();
		Citi_Legal_Entity_Id = citi_Legal_Entity_Id;
		Citi_Legal_Entity_Value = citi_Legal_Entity_Value;
	}


	public int getCiti_Legal_Entity_Id() {
		return Citi_Legal_Entity_Id;
	}

	public void setCiti_Legal_Entity_Id(int citi_Legal_Entity_Id) {
		Citi_Legal_Entity_Id = citi_Legal_Entity_Id;
	}

	public String getCiti_Legal_Entity_Value() {
		return Citi_Legal_Entity_Value;
	}

	public void setCiti_Legal_Entity_Value(String citi_Legal_Entity_Value) {
		Citi_Legal_Entity_Value = citi_Legal_Entity_Value;
	}

	public List<SowMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}
	
	

}
