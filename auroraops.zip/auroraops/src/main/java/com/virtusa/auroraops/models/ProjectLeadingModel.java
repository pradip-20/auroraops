package com.virtusa.auroraops.models;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;

import java.math.BigDecimal;
import java.sql.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ProjectLeadMaster")

@IdClass(ProjectLeadId.class)
public class ProjectLeadingModel {
	@Id
	@Column(name = "Chorus_Code",nullable = false)
	private int Chorus_Code;
	
	@Id
	@Column(name = "Year",nullable = false)
	private int Year;
	@Id
	@Column(name = "Month",columnDefinition="char(15)",nullable = false)
	private String Month;
	
	@Column(name = "Project_Health",columnDefinition="char(15)",nullable = false)
	private String Project_Health;
	
	@Column(name = "Revenue",nullable = false)
	private int Revenue;
	
	@Column(name = "Cost",nullable = false)
	private int Cost;
	
	@Column(name = "Margin",nullable = false)
	private BigDecimal Margin;
	
	@Column(name = "Cost_Tier0",nullable = false)
	private int Cost_Tier0;
	
	@Column(name = "Cost_Tier1",nullable = false)
	private int Cost_Tier1;
	
	@Column(name = "Cost_Tier2",nullable = false)
	private int Cost_Tier2;
	
	@Column(name = "Cost_Tier3",nullable = false)
	private int Cost_Tier3;
	
	@Column(name = "Cost_Tier4",nullable = false)
	private int Cost_Tier4;
	
	@Column(name = "FTE_Tier0",nullable = false)
	private BigDecimal FTE_Tier0;
	
	@Column(name = "FTE_Tier1",nullable = false)
	private BigDecimal FTE_Tier1;
	
	@Column(name = "FTE_Tier2",nullable = false)
	private BigDecimal FTE_Tier2;
	
	@Column(name = "FTE_Tier3",nullable = false)
	private BigDecimal FTE_Tier3;
	
	@Column(name = "FTE_Tier4",nullable = false)
	private BigDecimal FTE_Tier4;
	
	@Column(name = "Contractor_Cost",nullable = false)
	private int Contractor_Cost;
	
	@Column(name = "Contractor_Count",nullable = false)
	private int Contractor_Count;
	
	@Column(name = "Onsite_R_Cost_Tier0",nullable = false)
	private int Onsite_R_Cost_Tier0;
	
	@Column(name = "Onsite_R_Cost_Tier1",nullable = false)
	private int Onsite_R_Cost_Tier1;
	
	@Column(name = "Onsite_R_Cost_Tier2",nullable = false)
	private int Onsite_R_Cost_Tier2;
	
	@Column(name = "Onsite_R_Cost_Tier3",nullable = false)
	private int Onsite_R_Cost_Tier3;
	
	@Column(name = "Onsite_R_Cost_Tier4",nullable = false)
	private int Onsite_R_Cost_Tier4;
	
	@Column(name = "Offshore_R_Cost_Tier0",nullable = false)
	private int Offshore_R_Cost_Tier0;
	
	@Column(name = "Offshore_R_Cost_Tier1",nullable = false)
	private int Offshore_R_Cost_Tier1;
	
	@Column(name = "Offshore_R_Cost_Tier2",nullable = false)
	private int Offshore_R_Cost_Tier2;
	
	@Column(name = "Offshore_R_Cost_Tier3",nullable = false)
	private int Offshore_R_Cost_Tier3;
	
	@Column(name = "Offshore_R_Cost_Tier4",nullable = false)
	private int Offshore_R_Cost_Tier4;
	
	@Column(name = "Onsite_FTE_Tier0",nullable = false)
	private BigDecimal Onsite_FTE_Tier0;
	
	@Column(name = "Onsite_FTE_Tier1",nullable = false)
	private BigDecimal Onsite_FTE_Tier1;
	
	@Column(name = "Onsite_FTE_Tier2",nullable = false)
	private BigDecimal Onsite_FTE_Tier2;
	
	@Column(name = "Onsite_FTE_Tier3",nullable = false)
	private BigDecimal Onsite_FTE_Tier3;
	
	@Column(name = "Onsite_FTE_Tier4",nullable = false)
	private BigDecimal Onsite_FTE_Tier4;
	
	@Column(name = "Offshore_FTE_Tier0",nullable = false)
	private BigDecimal Offshore_FTE_Tier0;
	
	@Column(name = "Offshore_FTE_Tier1",nullable = false)
	private BigDecimal Offshore_FTE_Tier1;
	
	@Column(name = "Offshore_FTE_Tier2",nullable = false)
	private BigDecimal Offshore_FTE_Tier2;
	
	@Column(name = "Offshore_FTE_Tier3",nullable = false)
	private BigDecimal Offshore_FTE_Tier3;
	
	@Column(name = "Offshore_FTE_Tier4",nullable = false)
	private BigDecimal Offshore_FTE_Tier4;
	
	@Column(name = "DMI_Score",nullable = false)
	private BigDecimal DMI_Score;
	
	@Column(name = "Internal_Fulfillments_Number",nullable = false)
	private int Internal_Fulfillments_Number;
	
	@Column(name = "External_Fulfillments_Number",nullable = false)
	private int External_Fulfillments_Number;
	
	@Column(name = "Interviews_Held_Number",nullable = false)
	private int Interviews_Held_Number;
	
	@Column(name = "Client_Rejections_Number",nullable = false)
	private int Client_Rejections_Number;
	
	@Column(name = "Cost_Of_Hiring",nullable = false)
	private BigDecimal Cost_Of_Hiring;
	
	@Column(name = "Past_Due_RRs",nullable = false)
	private int Past_Due_RRs;
	
	@Column(name = "Ageing_Of_PastDue_RRs",nullable = false)
	private int Ageing_Of_PastDue_RRs;

	@Column(name = "SOW_Value",nullable = false)
	private BigDecimal SOW_Value;
	
	@Column(name = "EIP_Value",nullable = false)
	private BigDecimal EIP_Value;
	
	@Column(name = "Savings_RFP",nullable = false)
	private BigDecimal Savings_RFP;
	
	@Column(name = "Retention_Issue",nullable = false)
	private int Retention_Issue;
	
	@Column(name = "Resource_Onboarding_Delay",columnDefinition="char(15)",nullable = false)
	private String Resource_Onboarding_Delay;
	
	@Column(name = "EIQ_Baselining_Of_Resources",columnDefinition="char(15)",nullable = false)
	private String EIQ_Baselining_Of_Resources;
	
	@Column(name = "Churn_Attrition_Count",nullable = false)
	private int Churn_Attrition_Count;
	
	@Column(name = "Churn_Excused_Count",nullable = false)
	private int Churn_Excused_Count;

	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	
	@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	
	@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
	private String Modified_By;
	
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="Course_Code_fk")
	@MapsId
	private ChorusMasterModel cmodel;
	
	

	public ProjectLeadingModel(int chorus_Code, int year, String month, String project_Health, int revenue, int cost,
			BigDecimal margin, int cost_Tier0, int cost_Tier1, int cost_Tier2, int cost_Tier3, int cost_Tier4,
			BigDecimal fTE_Tier0, BigDecimal fTE_Tier1, BigDecimal fTE_Tier2, BigDecimal fTE_Tier3,
			BigDecimal fTE_Tier4, int contractor_Cost, int contractor_Count, int onsite_R_Cost_Tier0,
			int onsite_R_Cost_Tier1, int onsite_R_Cost_Tier2, int onsite_R_Cost_Tier3, int onsite_R_Cost_Tier4,
			int offshore_R_Cost_Tier0, int offshore_R_Cost_Tier1, int offshore_R_Cost_Tier2, int offshore_R_Cost_Tier3,
			int offshore_R_Cost_Tier4, BigDecimal onsite_FTE_Tier0, BigDecimal onsite_FTE_Tier1,
			BigDecimal onsite_FTE_Tier2, BigDecimal onsite_FTE_Tier3, BigDecimal onsite_FTE_Tier4,
			BigDecimal offshore_FTE_Tier0, BigDecimal offshore_FTE_Tier1, BigDecimal offshore_FTE_Tier2,
			BigDecimal offshore_FTE_Tier3, BigDecimal offshore_FTE_Tier4, BigDecimal dMI_Score,
			int internal_Fulfillments_Number, int external_Fulfillments_Number, int interviews_Held_Number,
			int client_Rejections_Number, BigDecimal cost_Of_Hiring, int past_Due_RRs, int ageing_Of_PastDue_RRs,
			BigDecimal sOW_Value, BigDecimal eIP_Value, BigDecimal savings_RFP, int retention_Issue,
			String resource_Onboarding_Delay, String eIQ_Baselining_Of_Resources, int churn_Attrition_Count,
			int churn_Excused_Count, Date created_Date, String created_By, Date modified_Date, String modified_By,
			ChorusMasterModel cmodel) {
		super();
		Chorus_Code = chorus_Code;
		Year = year;
		Month = month;
		Project_Health = project_Health;
		Revenue = revenue;
		Cost = cost;
		Margin = margin;
		Cost_Tier0 = cost_Tier0;
		Cost_Tier1 = cost_Tier1;
		Cost_Tier2 = cost_Tier2;
		Cost_Tier3 = cost_Tier3;
		Cost_Tier4 = cost_Tier4;
		FTE_Tier0 = fTE_Tier0;
		FTE_Tier1 = fTE_Tier1;
		FTE_Tier2 = fTE_Tier2;
		FTE_Tier3 = fTE_Tier3;
		FTE_Tier4 = fTE_Tier4;
		Contractor_Cost = contractor_Cost;
		Contractor_Count = contractor_Count;
		Onsite_R_Cost_Tier0 = onsite_R_Cost_Tier0;
		Onsite_R_Cost_Tier1 = onsite_R_Cost_Tier1;
		Onsite_R_Cost_Tier2 = onsite_R_Cost_Tier2;
		Onsite_R_Cost_Tier3 = onsite_R_Cost_Tier3;
		Onsite_R_Cost_Tier4 = onsite_R_Cost_Tier4;
		Offshore_R_Cost_Tier0 = offshore_R_Cost_Tier0;
		Offshore_R_Cost_Tier1 = offshore_R_Cost_Tier1;
		Offshore_R_Cost_Tier2 = offshore_R_Cost_Tier2;
		Offshore_R_Cost_Tier3 = offshore_R_Cost_Tier3;
		Offshore_R_Cost_Tier4 = offshore_R_Cost_Tier4;
		Onsite_FTE_Tier0 = onsite_FTE_Tier0;
		Onsite_FTE_Tier1 = onsite_FTE_Tier1;
		Onsite_FTE_Tier2 = onsite_FTE_Tier2;
		Onsite_FTE_Tier3 = onsite_FTE_Tier3;
		Onsite_FTE_Tier4 = onsite_FTE_Tier4;
		Offshore_FTE_Tier0 = offshore_FTE_Tier0;
		Offshore_FTE_Tier1 = offshore_FTE_Tier1;
		Offshore_FTE_Tier2 = offshore_FTE_Tier2;
		Offshore_FTE_Tier3 = offshore_FTE_Tier3;
		Offshore_FTE_Tier4 = offshore_FTE_Tier4;
		DMI_Score = dMI_Score;
		Internal_Fulfillments_Number = internal_Fulfillments_Number;
		External_Fulfillments_Number = external_Fulfillments_Number;
		Interviews_Held_Number = interviews_Held_Number;
		Client_Rejections_Number = client_Rejections_Number;
		Cost_Of_Hiring = cost_Of_Hiring;
		Past_Due_RRs = past_Due_RRs;
		Ageing_Of_PastDue_RRs = ageing_Of_PastDue_RRs;
		SOW_Value = sOW_Value;
		EIP_Value = eIP_Value;
		Savings_RFP = savings_RFP;
		Retention_Issue = retention_Issue;
		Resource_Onboarding_Delay = resource_Onboarding_Delay;
		EIQ_Baselining_Of_Resources = eIQ_Baselining_Of_Resources;
		Churn_Attrition_Count = churn_Attrition_Count;
		Churn_Excused_Count = churn_Excused_Count;
		Created_Date = created_Date;
		Created_By = created_By;
		Modified_Date = modified_Date;
		Modified_By = modified_By;
		this.cmodel = cmodel;
	}

	public int getChorus_Code() {
		return Chorus_Code;
	}

	public void setChorus_Code(int chorus_Code) {
		Chorus_Code = chorus_Code;
	}

	public int getYear() {
		return Year;
	}

	public void setYear(int year) {
		Year = year;
	}

	public String getMonth() {
		return Month;
	}

	public void setMonth(String month) {
		Month = month;
	}

	public String getProject_Health() {
		return Project_Health;
	}

	public void setProject_Health(String project_Health) {
		Project_Health = project_Health;
	}

	public int getRevenue() {
		return Revenue;
	}

	public void setRevenue(int revenue) {
		Revenue = revenue;
	}

	public int getCost() {
		return Cost;
	}

	public void setCost(int cost) {
		Cost = cost;
	}

	public BigDecimal getMargin() {
		return Margin;
	}

	public void setMargin(BigDecimal margin) {
		Margin = margin;
	}

	public int getCost_Tier0() {
		return Cost_Tier0;
	}

	public void setCost_Tier0(int cost_Tier0) {
		Cost_Tier0 = cost_Tier0;
	}

	public int getCost_Tier1() {
		return Cost_Tier1;
	}

	public void setCost_Tier1(int cost_Tier1) {
		Cost_Tier1 = cost_Tier1;
	}

	public int getCost_Tier2() {
		return Cost_Tier2;
	}

	public void setCost_Tier2(int cost_Tier2) {
		Cost_Tier2 = cost_Tier2;
	}

	public int getCost_Tier3() {
		return Cost_Tier3;
	}

	public void setCost_Tier3(int cost_Tier3) {
		Cost_Tier3 = cost_Tier3;
	}

	public int getCost_Tier4() {
		return Cost_Tier4;
	}

	public void setCost_Tier4(int cost_Tier4) {
		Cost_Tier4 = cost_Tier4;
	}

	public BigDecimal getFTE_Tier0() {
		return FTE_Tier0;
	}

	public void setFTE_Tier0(BigDecimal fTE_Tier0) {
		FTE_Tier0 = fTE_Tier0;
	}

	public BigDecimal getFTE_Tier1() {
		return FTE_Tier1;
	}

	public void setFTE_Tier1(BigDecimal fTE_Tier1) {
		FTE_Tier1 = fTE_Tier1;
	}

	public BigDecimal getFTE_Tier2() {
		return FTE_Tier2;
	}

	public void setFTE_Tier2(BigDecimal fTE_Tier2) {
		FTE_Tier2 = fTE_Tier2;
	}

	public BigDecimal getFTE_Tier3() {
		return FTE_Tier3;
	}

	public void setFTE_Tier3(BigDecimal fTE_Tier3) {
		FTE_Tier3 = fTE_Tier3;
	}

	public BigDecimal getFTE_Tier4() {
		return FTE_Tier4;
	}

	public void setFTE_Tier4(BigDecimal fTE_Tier4) {
		FTE_Tier4 = fTE_Tier4;
	}

	public int getContractor_Cost() {
		return Contractor_Cost;
	}

	public void setContractor_Cost(int contractor_Cost) {
		Contractor_Cost = contractor_Cost;
	}

	public int getContractor_Count() {
		return Contractor_Count;
	}

	public void setContractor_Count(int contractor_Count) {
		Contractor_Count = contractor_Count;
	}

	public int getOnsite_R_Cost_Tier0() {
		return Onsite_R_Cost_Tier0;
	}

	public void setOnsite_R_Cost_Tier0(int onsite_R_Cost_Tier0) {
		Onsite_R_Cost_Tier0 = onsite_R_Cost_Tier0;
	}

	public int getOnsite_R_Cost_Tier1() {
		return Onsite_R_Cost_Tier1;
	}

	public void setOnsite_R_Cost_Tier1(int onsite_R_Cost_Tier1) {
		Onsite_R_Cost_Tier1 = onsite_R_Cost_Tier1;
	}

	public int getOnsite_R_Cost_Tier2() {
		return Onsite_R_Cost_Tier2;
	}

	public void setOnsite_R_Cost_Tier2(int onsite_R_Cost_Tier2) {
		Onsite_R_Cost_Tier2 = onsite_R_Cost_Tier2;
	}

	public int getOnsite_R_Cost_Tier3() {
		return Onsite_R_Cost_Tier3;
	}

	public void setOnsite_R_Cost_Tier3(int onsite_R_Cost_Tier3) {
		Onsite_R_Cost_Tier3 = onsite_R_Cost_Tier3;
	}

	public int getOnsite_R_Cost_Tier4() {
		return Onsite_R_Cost_Tier4;
	}

	public void setOnsite_R_Cost_Tier4(int onsite_R_Cost_Tier4) {
		Onsite_R_Cost_Tier4 = onsite_R_Cost_Tier4;
	}

	public int getOffshore_R_Cost_Tier0() {
		return Offshore_R_Cost_Tier0;
	}

	public void setOffshore_R_Cost_Tier0(int offshore_R_Cost_Tier0) {
		Offshore_R_Cost_Tier0 = offshore_R_Cost_Tier0;
	}

	public int getOffshore_R_Cost_Tier1() {
		return Offshore_R_Cost_Tier1;
	}

	public void setOffshore_R_Cost_Tier1(int offshore_R_Cost_Tier1) {
		Offshore_R_Cost_Tier1 = offshore_R_Cost_Tier1;
	}

	public int getOffshore_R_Cost_Tier2() {
		return Offshore_R_Cost_Tier2;
	}

	public void setOffshore_R_Cost_Tier2(int offshore_R_Cost_Tier2) {
		Offshore_R_Cost_Tier2 = offshore_R_Cost_Tier2;
	}

	public int getOffshore_R_Cost_Tier3() {
		return Offshore_R_Cost_Tier3;
	}

	public void setOffshore_R_Cost_Tier3(int offshore_R_Cost_Tier3) {
		Offshore_R_Cost_Tier3 = offshore_R_Cost_Tier3;
	}

	public int getOffshore_R_Cost_Tier4() {
		return Offshore_R_Cost_Tier4;
	}

	public void setOffshore_R_Cost_Tier4(int offshore_R_Cost_Tier4) {
		Offshore_R_Cost_Tier4 = offshore_R_Cost_Tier4;
	}

	public BigDecimal getOnsite_FTE_Tier0() {
		return Onsite_FTE_Tier0;
	}

	public void setOnsite_FTE_Tier0(BigDecimal onsite_FTE_Tier0) {
		Onsite_FTE_Tier0 = onsite_FTE_Tier0;
	}

	public BigDecimal getOnsite_FTE_Tier1() {
		return Onsite_FTE_Tier1;
	}

	public void setOnsite_FTE_Tier1(BigDecimal onsite_FTE_Tier1) {
		Onsite_FTE_Tier1 = onsite_FTE_Tier1;
	}

	public BigDecimal getOnsite_FTE_Tier2() {
		return Onsite_FTE_Tier2;
	}

	public void setOnsite_FTE_Tier2(BigDecimal onsite_FTE_Tier2) {
		Onsite_FTE_Tier2 = onsite_FTE_Tier2;
	}

	public BigDecimal getOnsite_FTE_Tier3() {
		return Onsite_FTE_Tier3;
	}

	public void setOnsite_FTE_Tier3(BigDecimal onsite_FTE_Tier3) {
		Onsite_FTE_Tier3 = onsite_FTE_Tier3;
	}

	public BigDecimal getOnsite_FTE_Tier4() {
		return Onsite_FTE_Tier4;
	}

	public void setOnsite_FTE_Tier4(BigDecimal onsite_FTE_Tier4) {
		Onsite_FTE_Tier4 = onsite_FTE_Tier4;
	}

	public BigDecimal getOffshore_FTE_Tier0() {
		return Offshore_FTE_Tier0;
	}

	public void setOffshore_FTE_Tier0(BigDecimal offshore_FTE_Tier0) {
		Offshore_FTE_Tier0 = offshore_FTE_Tier0;
	}

	public BigDecimal getOffshore_FTE_Tier1() {
		return Offshore_FTE_Tier1;
	}

	public void setOffshore_FTE_Tier1(BigDecimal offshore_FTE_Tier1) {
		Offshore_FTE_Tier1 = offshore_FTE_Tier1;
	}

	public BigDecimal getOffshore_FTE_Tier2() {
		return Offshore_FTE_Tier2;
	}

	public void setOffshore_FTE_Tier2(BigDecimal offshore_FTE_Tier2) {
		Offshore_FTE_Tier2 = offshore_FTE_Tier2;
	}

	public BigDecimal getOffshore_FTE_Tier3() {
		return Offshore_FTE_Tier3;
	}

	public void setOffshore_FTE_Tier3(BigDecimal offshore_FTE_Tier3) {
		Offshore_FTE_Tier3 = offshore_FTE_Tier3;
	}

	public BigDecimal getOffshore_FTE_Tier4() {
		return Offshore_FTE_Tier4;
	}

	public void setOffshore_FTE_Tier4(BigDecimal offshore_FTE_Tier4) {
		Offshore_FTE_Tier4 = offshore_FTE_Tier4;
	}

	public BigDecimal getDMI_Score() {
		return DMI_Score;
	}

	public void setDMI_Score(BigDecimal dMI_Score) {
		DMI_Score = dMI_Score;
	}

	public int getInternal_Fulfillments_Number() {
		return Internal_Fulfillments_Number;
	}

	public void setInternal_Fulfillments_Number(int internal_Fulfillments_Number) {
		Internal_Fulfillments_Number = internal_Fulfillments_Number;
	}

	public int getExternal_Fulfillments_Number() {
		return External_Fulfillments_Number;
	}

	public void setExternal_Fulfillments_Number(int external_Fulfillments_Number) {
		External_Fulfillments_Number = external_Fulfillments_Number;
	}

	public int getInterviews_Held_Number() {
		return Interviews_Held_Number;
	}

	public void setInterviews_Held_Number(int interviews_Held_Number) {
		Interviews_Held_Number = interviews_Held_Number;
	}

	public int getClient_Rejections_Number() {
		return Client_Rejections_Number;
	}

	public void setClient_Rejections_Number(int client_Rejections_Number) {
		Client_Rejections_Number = client_Rejections_Number;
	}

	public BigDecimal getCost_Of_Hiring() {
		return Cost_Of_Hiring;
	}

	public void setCost_Of_Hiring(BigDecimal cost_Of_Hiring) {
		Cost_Of_Hiring = cost_Of_Hiring;
	}

	public int getPast_Due_RRs() {
		return Past_Due_RRs;
	}

	public void setPast_Due_RRs(int past_Due_RRs) {
		Past_Due_RRs = past_Due_RRs;
	}

	public int getAgeing_Of_PastDue_RRs() {
		return Ageing_Of_PastDue_RRs;
	}

	public void setAgeing_Of_PastDue_RRs(int ageing_Of_PastDue_RRs) {
		Ageing_Of_PastDue_RRs = ageing_Of_PastDue_RRs;
	}

	public BigDecimal getSOW_Value() {
		return SOW_Value;
	}

	public void setSOW_Value(BigDecimal sOW_Value) {
		SOW_Value = sOW_Value;
	}

	public BigDecimal getEIP_Value() {
		return EIP_Value;
	}

	public void setEIP_Value(BigDecimal eIP_Value) {
		EIP_Value = eIP_Value;
	}

	public BigDecimal getSavings_RFP() {
		return Savings_RFP;
	}

	public void setSavings_RFP(BigDecimal savings_RFP) {
		Savings_RFP = savings_RFP;
	}

	public int getRetention_Issue() {
		return Retention_Issue;
	}

	public void setRetention_Issue(int retention_Issue) {
		Retention_Issue = retention_Issue;
	}

	public String getResource_Onboarding_Delay() {
		return Resource_Onboarding_Delay;
	}

	public void setResource_Onboarding_Delay(String resource_Onboarding_Delay) {
		Resource_Onboarding_Delay = resource_Onboarding_Delay;
	}

	public String getEIQ_Baselining_Of_Resources() {
		return EIQ_Baselining_Of_Resources;
	}

	public void setEIQ_Baselining_Of_Resources(String eIQ_Baselining_Of_Resources) {
		EIQ_Baselining_Of_Resources = eIQ_Baselining_Of_Resources;
	}

	public int getChurn_Attrition_Count() {
		return Churn_Attrition_Count;
	}

	public void setChurn_Attrition_Count(int churn_Attrition_Count) {
		Churn_Attrition_Count = churn_Attrition_Count;
	}

	public int getChurn_Excused_Count() {
		return Churn_Excused_Count;
	}

	public void setChurn_Excused_Count(int churn_Excused_Count) {
		Churn_Excused_Count = churn_Excused_Count;
	}

	public Date getCreated_Date() {
		return Created_Date;
	}

	public void setCreated_Date(Date created_Date) {
		Created_Date = created_Date;
	}

	public String getCreated_By() {
		return Created_By;
	}

	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}

	public Date getModified_Date() {
		return Modified_Date;
	}

	public void setModified_Date(Date modified_Date) {
		Modified_Date = modified_Date;
	}

	public String getModified_By() {
		return Modified_By;
	}

	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}

	public ChorusMasterModel getCmodel() {
		return cmodel;
	}

	public void setCmodel(ChorusMasterModel cmodel) {
		this.cmodel = cmodel;
	}

	

}
