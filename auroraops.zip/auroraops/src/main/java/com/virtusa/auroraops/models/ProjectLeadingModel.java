package com.virtusa.auroraops.models;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;

import java.math.BigDecimal;
import java.sql.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ProjectLeadMaster")

@IdClass(ProjectLeadId.class)
public class ProjectLeadingModel {
	@Id
	@Column(name = "Chorus_Code",nullable = false)
	private int Chorus_Code;
	
	@Id
	@Column(name = "Year",nullable = false)
	private int Year;
	@Id
	@Column(name = "Month",columnDefinition="char(15)",nullable = false)
	private String Month;
	
	@Column(name = "Data",columnDefinition="char(15)",nullable = false)
	private String Data;
	
	
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="Course_Code_fk")
	@MapsId
	private ChorusMasterModel cmodel;
	
	
	
	public ProjectLeadingModel() {
	}

	public ProjectLeadingModel(int chorus_Code, int year, String month, String data) {
		super();
		Chorus_Code = chorus_Code;
		Year = year;
		Month = month;
		Data = data;
	}


	public int getChorus_Code() {
		return Chorus_Code;
	}


	public void setChorus_Code(int chorus_Code) {
		Chorus_Code = chorus_Code;
	}


	public int getYear() {
		return Year;
	}


	public void setYear(int year) {
		Year = year;
	}


	public String getMonth() {
		return Month;
	}


	public void setMonth(String month) {
		Month = month;
	}


	public String getData() {
		return Data;
	}


	public void setData(String data) {
		Data = data;
	}


	public ChorusMasterModel getCmodel() {
		return cmodel;
	}


	public void setCmodel(ChorusMasterModel cmodel) {
		this.cmodel = cmodel;
	}
	

	
	
	
	
	
	
	
	
	/*@Id
	@Column(name = "Chorus_Code",nullable = false)
	private int Chorus_Code;

	@Column(name = "Velocity_ProjectCode",nullable = false)
	private int Velocity_ProjectCode;
	
	@Column(name = "Process_Template",columnDefinition="char(15)",nullable = false)
	private String Process_Template;
	
	@Column(name = "Project_Health",columnDefinition="char(15)",nullable = false)
	private String Project_Health;
	
	@Column(name = "Internal_Fulfillments_Number",nullable = false)
	private int Internal_Fulfillments_Number;
	
	@Column(name = "External_Fulfillments_Number",nullable = false)
	private int External_Fulfillments_Number;
	
	@Column(name = "Interviews_Held_Number",nullable = false)
	private int Interviews_Held_Number;
	
	@Column(name = "Client_Rejections_Number",nullable = false)
	private int Client_Rejections_Number;
	
	@Column(name = "Cost_Of_Hiring",nullable = false)
	private BigDecimal Cost_Of_Hiring;
	
	@Column(name = "Past_Due_RRs",nullable = false)
	private int Past_Due_RRs;
	
	@Column(name = "Ageing_Of_PastDue_RRs",nullable = false)
	private int Ageing_Of_PastDue_RRs;
	
	@Column(name = "SOW_Value",nullable = false)
	private BigDecimal SOW_Value;
	
	@Column(name = "EIP_Value",nullable = false)
	private BigDecimal EIP_Value;
	
	@Column(name = "Savings_RFP",nullable = false)
	private BigDecimal Savings_RFP;
	
	
	@Column(name = "Retention_Issue",nullable = false)
	private int Retention_Issue;
	
	@Column(name = "Resource_Onboarding_Delay",columnDefinition="char(15)",nullable = false)
	private String Resource_Onboarding_Delay;
	
	@Column(name = "EIQ_Baselining_Of_Resources",columnDefinition="char(15)",nullable = false)
	private String EIQ_Baselining_Of_Resources;
	
	@Column(name = "Churn_Attrition_Count",nullable = false)
	private int Churn_Attrition_Count;
	
	@Column(name = "Churn_Excused_Count",nullable = false)
	private int Churn_Excused_Count;*/
	

}
