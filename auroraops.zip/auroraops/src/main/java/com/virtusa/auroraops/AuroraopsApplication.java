package com.virtusa.auroraops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuroraopsApplication {

	public static void main(String[] args) {
		
		System.out.print("Hello Virtusa OpsDetails");
		SpringApplication.run(AuroraopsApplication.class, args);
	}

}
