package com.virtusa.auroraops.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.auroraops.models.ProjectMasterModel;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectMasterRepository extends JpaRepository<ProjectMasterModel,Integer> {

}
