package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="SectorMaster")

public class SectorMasterModel {
	@Id
	@Column(name = "Sector_Id",nullable = false)
	private int Sector_Id;
	
	@Column(name = "Sector_Value",columnDefinition="char(30)",nullable = false)
	private String Sector_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Sector_Id_fk_int",referencedColumnName="Sector_Id")
	List<SowMasterModel> smodel = new ArrayList<>();
	public SectorMasterModel() {
		
	}

	

	public SectorMasterModel(int sector_Id, String sector_Value) {
		super();
		Sector_Id = sector_Id;
		Sector_Value = sector_Value;
	}



	public int getSector_Id() {
		return Sector_Id;
	}

	public void setSector_Id(int sector_Id) {
		Sector_Id = sector_Id;
	}

	public String getSector_Value() {
		return Sector_Value;
	}

	public void setSector_Value(String sector_Value) {
		Sector_Value = sector_Value;
	}

	public List<SowMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}

	

}
