package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ProjectMaster")

public class ProjectMasterModel {
	@Id
	@Column(name = "Project_Id",nullable = false)
	private int Project_Id;
	
	@Column(name = "Project_Status",columnDefinition="char(15)",nullable = false)
	private String Project_Status;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Project_Id_fk_int",referencedColumnName="Project_Id",nullable=false)
	List<ChorusMasterModel> cmodel = new ArrayList<>();
	
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Project_Id_fk_int",referencedColumnName="Project_Id",nullable=false)
	List<ResourcesMasterModel> resourceMasterModel = new ArrayList<>();
		
	
	public ProjectMasterModel()
	{
		
	}
	


	public ProjectMasterModel(int project_Id, String project_Status) {
		super();
		Project_Id = project_Id;
		Project_Status = project_Status;
	}



	public int getProject_Id() {
		return Project_Id;
	}


	public void setProject_Id(int project_Id) {
		Project_Id = project_Id;
	}


	public String getProject_Status() {
		return Project_Status;
	}


	public void setProject_Status(String project_Status) {
		Project_Status = project_Status;
	}


	public List<ChorusMasterModel> getCmodel() {
		return cmodel;
	}


	public void setCmodel(List<ChorusMasterModel> cmodel) {
		this.cmodel = cmodel;
	}


	public List<ResourcesMasterModel> getResourceMasterModel() {
		return resourceMasterModel;
	}


	public void setResourceMasterModel(List<ResourcesMasterModel> resourceMasterModel) {
		this.resourceMasterModel = resourceMasterModel;
	}


		/*
		 @Column(name = "Project_Id",nullable = false)
	private int Project_Id;
	
	 @Column(name = "Velocity_ProjectCode",columnDefinition="char(100)",nullable = false)
	private String Velocity_ProjectCode;
	
		@Column(name = "Project_Name",columnDefinition="char(100)",nullable = false)
	private String Project_Name;
		 
		 @Column(name = "Resources_Currently_Allocated",columnDefinition="char(100)",nullable = false)
	private String Resources_Currently_Allocated;
	
	@Column(name = "Velocity_Start_Date",nullable = false)
	private Date Velocity_Start_Date;
	
	@Column(name = "Velocity_End_Date",nullable = false)
	private Date Velocity_End_Date;
	
	@Column(name = "Virtusa_Segment_DeliveryHead",columnDefinition="char(100)",nullable = false)
	private String Virtusa_Segment_DeliveryHead;
	
	@Column(name = "Virtusa_DD_Name",columnDefinition="char(100)",nullable = false)
	private String Virtusa_DD_Name;
	
	@Column(name = "Virtusa_DD_EmailId",columnDefinition="char(100)",nullable = false)
	private String Virtusa_DD_EmailId;
	
	@Column(name = "Virtusa_PD_Name",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PD_Name;
	
	@Column(name = "Virtusa_PD_EmailId",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PD_EmailId;
	
	@Column(name = "Virtusa_PM_Name",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PM_Name;
	
	@Column(name = "Virtusa_PM_EmailId",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PM_EmailId;
	
	@Column(name = "IT_Cluster",columnDefinition="char(100)",nullable = false)
	private String IT_Cluster;
	
	 @Column(name = "Total_HC",nullable = false)
	private int Total_HC;
	
	 @Column(name = "HC_On",nullable = false)
	private int HC_On;
	
	 @Column(name = "HC_Off",nullable = false)
	private int HC_Off;
	
	@Column(name = "Recovery_Time_Objective",columnDefinition="char(100)",nullable = false)
	private String Recovery_Time_Objective;
	
	@Column(name = "Engagement_Plan_Applicability",columnDefinition="char(100)",nullable = false)
	private String Engagement_Plan_Applicability;
	
	@Column(name = "Engagement_Plan_Exemption_Reason",columnDefinition="char(100)",nullable = false)
	private String Engagement_Plan_Exemption_Reason;
	
	@Column(name = "SLA_Applicability",columnDefinition="char(100)",nullable = false)
	private String SLA_Applicability;
	
	@Column(name = "KPI_Applicability",columnDefinition="char(100)",nullable = false)
	private String KPI_Applicability;
	
	 @Column(name = "Key_Personnel_Including_PM",nullable = false)
	private int Key_Personnel_Including_PM;
	
	
	@Column(name = "Project_Life_Cycle",columnDefinition="char(100)",nullable = false)
	private String Project_Life_Cycle;
	
	@Column(name = "Project_Applicability_Secure_SDLC",columnDefinition="char(100)",nullable = false)
	private String Project_Applicability_Secure_SDLC;
	
	@Column(name = "Project_Mobile_Development_Component",columnDefinition="char(100)",nullable = false)
	private String Project_Mobile_Development_Component;
	
	@Column(name = "Release_Notes_Applicability",columnDefinition="char(100)",nullable = false)
	private String Release_Notes_Applicability;
	
	@Column(name = "Self_Assessment_Applicability",columnDefinition="char(100)",nullable = false)
	private String Self_Assessment_Applicability;
	
	@Column(name = "Governance_Report_Applicability",columnDefinition="char(100)",nullable = false)
	private String Governance_Report_Applicability;
	
	@Column(name = "Governance_Report_Frequency",columnDefinition="char(100)",nullable = false)
	private String Governance_Report_Frequency;
	
	@Column(name = "GDPR",columnDefinition="char(100)",nullable = false)
	private String GDPR;
	
	@Column(name = "Remarks",columnDefinition="char(100)",nullable = false)
	private String Remarks;
	@Column(name = "Highest_Confidentiality",columnDefinition="char(100)",nullable = false)
	private String Highest_Confidentiality;
	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
	private String Modified_By;
	
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	
		 */
	
	

 
}
