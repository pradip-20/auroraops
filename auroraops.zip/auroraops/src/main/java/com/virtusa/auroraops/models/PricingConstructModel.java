package com.virtusa.auroraops.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="PricingConstructMaster")

public class PricingConstructModel {

	@Id
	@Column(name = "Pricing_Construct_Code",nullable = false)
	private int Pricing_Construct_Code;
	
	@Column(name = "Pricing_Construct_Value",columnDefinition="char(30)",nullable = false)
	private String Pricing_Construct_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Pricing_Construct_Code_fk_int",referencedColumnName="Pricing_Construct_Code")
	List<ProjectMasterModel> smodel = new ArrayList<>();
	
	public PricingConstructModel() {
		
	}
	
	
	public PricingConstructModel(int pricing_Construct_Code, String pricing_Construct_Value,
			List<ProjectMasterModel> smodel) {
		super();
		Pricing_Construct_Code = pricing_Construct_Code;
		Pricing_Construct_Value = pricing_Construct_Value;
		this.smodel = smodel;
	}

	public int getPricing_Construct_Code() {
		return Pricing_Construct_Code;
	}

	public void setPricing_Construct_Code(int pricing_Construct_Code) {
		Pricing_Construct_Code = pricing_Construct_Code;
	}

	public String getPricing_Construct_Value() {
		return Pricing_Construct_Value;
	}

	public void setPricing_Construct_Value(String pricing_Construct_Value) {
		Pricing_Construct_Value = pricing_Construct_Value;
	}

	public List<ProjectMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<ProjectMasterModel> smodel) {
		this.smodel = smodel;
	}
	
	
	
}
