package com.virtusa.auroraops.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.auroraops.dto.OrderResponse;
import com.virtusa.auroraops.repositories.SegmentMasterRepository;
@RestController
@RequestMapping("/api/citi-portal")
public class AuroraOpsController {

	@Autowired
	private SegmentMasterRepository segrepository;

	

	public void setSegrepository(SegmentMasterRepository segrepository) {
		this.segrepository = segrepository;
	}


     @GetMapping("/getInfo")
	public List<OrderResponse> fetchData(){
		return segrepository.getJoinInformation();
	}
}
