package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="DeliveryMaster")

public class DeliveryFromModel {
	@Id
	@Column(name = "Delivery_From_Id",nullable = false)
	private int Program_Id;
	
	@Column(name = "Delivery_From_Value",columnDefinition="char(30)",nullable = false)
	private String Delivery_From_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Deliveries_id_fk_int",referencedColumnName="Delivery_From_Id")
	List<ProjectMasterModel> pmodel = new ArrayList<>();
	
	public DeliveryFromModel() {
		
	}
	

	

	public DeliveryFromModel(int program_Id, String delivery_From_Value) {
		super();
		Program_Id = program_Id;
		Delivery_From_Value = delivery_From_Value;
	}




	public int getProgram_Id() {
		return Program_Id;
	}

	public void setProgram_Id(int program_Id) {
		Program_Id = program_Id;
	}

	public String getDelivery_From_Value() {
		return Delivery_From_Value;
	}

	public void setDelivery_From_Value(String delivery_From_Value) {
		Delivery_From_Value = delivery_From_Value;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}
	


}
