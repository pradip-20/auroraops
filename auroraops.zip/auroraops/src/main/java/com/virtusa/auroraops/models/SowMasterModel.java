package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="SowMaster")
public class SowMasterModel {

	@Id
	@Column(name = "Aurora_SOW_Seq",nullable = false)
	private int Aurora_SOW_Seq;
	
	
	@Column(name = "SOW_Contract_Id",columnDefinition="char(100)",nullable = false)
	private String SOW_Contract_Id;
	
	@Column(name = "SOW_Contract_Pred_Id",columnDefinition="char(100)",nullable = false)
	private String SOW_Contract_Pred_Id;
	
	@Column(name = "Contract_Name",columnDefinition="char(15)",nullable = false)
	private String Contract_Name;
	
	
	@Column(name = "Signed_Effective_Date",nullable = false)
	private Date Signed_Effective_Date;
	
	@Column(name = "Sow_Strart_Date",nullable = false)
	private Date Sow_Strart_Date;
	
	@Column(name = "Sow_End_Date",nullable = false)
	private Date Sow_End_Date;
	
	@Column(name = "Tenure",nullable = false)
	private int Tenure;
	
	@Column(name = "FG_Id",columnDefinition="char(100)",nullable = false)
	private String FG_Id;
	
	@Column(name = "Source_Data",columnDefinition="char(100)",nullable = false)
	private String Source_Data;
	
	@Column(name = "Sow_Status",columnDefinition="char(1)",nullable = false)
	private String Sow_Status;

	@Column(name = "Geography",columnDefinition="char(100)",nullable = false)
	private String Geography;
	
	@Column(name = "Area",columnDefinition="char(100)",nullable = false)
	private String Area;
	
	@Column(name = "Citi_SOWOwner_Name",columnDefinition="char(100)",nullable = false)
	private String Citi_SOWOwner_Name;
	
	@Column(name = "Citi_SOWOwner_Email_Id",columnDefinition="char(100)",nullable = false)
	private String Citi_SOWOwner_Email_Id;
	
	@Column(name = "Citi_PM",columnDefinition="char(100)",nullable = false)
	private String Citi_PM;
	
	@Column(name = "Citi_PM_EmailId",columnDefinition="char(100)",nullable = false)
	private String Citi_PM_EmailId;
	
	@Column(name = "Virtusa_PM_Name",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PM_Name;
	
	@Column(name = "Virtusa_PM_EmailId",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PM_EmailId;
	
	@Column(name = "AutoEmail_TriggerdFlag",columnDefinition="char(1)",nullable = false)
	private String autoemailtriggeredflag;
	
	@Column(name = "AutoEmail_TriggeredDate",nullable = false)
	private Date autoemailtriggereddate;
	
	@Column(name = "Key_Personnel_SOW_Count",nullable = false)
	private int Key_Personnel_SOW_Count;
	
	@Column(name = "COB_Applicability",columnDefinition="char(1)",nullable = false)
	private String COB_Applicability;
	
	@Column(name = "Remarks",columnDefinition="char(100)",nullable = false)
	private String Remarks;
	
	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	
	@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	
	
	
	@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
	private String Modified_By;


	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Aurora_SOW_Seq_fk_int",referencedColumnName="Aurora_SOW_Seq",nullable = false)
	List<ProjectMasterModel> pmodel = new ArrayList<>();
	
	public SowMasterModel() {
		
	}

		
	public SowMasterModel(int aurora_SOW_Seq, String sOW_Contract_Id, String sOW_Contract_Pred_Id, String contract_Name,
			Date signed_Effective_Date, Date sow_Strart_Date, Date sow_End_Date, int tenure, String fG_Id,
			String source_Data, String sow_Status, String geography, String area, String citi_SOWOwner_Name,
			String citi_SOWOwner_Email_Id, String citi_PM, String citi_PM_EmailId, String virtusa_PM_Name,
			String virtusa_PM_EmailId, String autoemailtriggeredflag, Date autoemailtriggereddate,
			int key_Personnel_SOW_Count, String cOB_Applicability, String remarks, Date created_Date, String created_By,
			Date modified_Date, String modified_By, List<ProjectMasterModel> pmodel) {
		super();
		Aurora_SOW_Seq = aurora_SOW_Seq;
		SOW_Contract_Id = sOW_Contract_Id;
		SOW_Contract_Pred_Id = sOW_Contract_Pred_Id;
		Contract_Name = contract_Name;
		Signed_Effective_Date = signed_Effective_Date;
		Sow_Strart_Date = sow_Strart_Date;
		Sow_End_Date = sow_End_Date;
		Tenure = tenure;
		FG_Id = fG_Id;
		Source_Data = source_Data;
		Sow_Status = sow_Status;
		Geography = geography;
		Area = area;
		Citi_SOWOwner_Name = citi_SOWOwner_Name;
		Citi_SOWOwner_Email_Id = citi_SOWOwner_Email_Id;
		Citi_PM = citi_PM;
		Citi_PM_EmailId = citi_PM_EmailId;
		Virtusa_PM_Name = virtusa_PM_Name;
		Virtusa_PM_EmailId = virtusa_PM_EmailId;
		this.autoemailtriggeredflag = autoemailtriggeredflag;
		this.autoemailtriggereddate = autoemailtriggereddate;
		Key_Personnel_SOW_Count = key_Personnel_SOW_Count;
		COB_Applicability = cOB_Applicability;
		Remarks = remarks;
		Created_Date = created_Date;
		Created_By = created_By;
		Modified_Date = modified_Date;
		Modified_By = modified_By;
		this.pmodel = pmodel;
	}


	public int getAurora_SOW_Seq() {
		return Aurora_SOW_Seq;
	}

	public void setAurora_SOW_Seq(int aurora_SOW_Seq) {
		Aurora_SOW_Seq = aurora_SOW_Seq;
	}

	public String getSOW_Contract_Id() {
		return SOW_Contract_Id;
	}

	public void setSOW_Contract_Id(String sOW_Contract_Id) {
		SOW_Contract_Id = sOW_Contract_Id;
	}

	public String getSOW_Contract_Pred_Id() {
		return SOW_Contract_Pred_Id;
	}

	public void setSOW_Contract_Pred_Id(String sOW_Contract_Pred_Id) {
		SOW_Contract_Pred_Id = sOW_Contract_Pred_Id;
	}

	public String getContract_Name() {
		return Contract_Name;
	}

	public void setContract_Name(String contract_Name) {
		Contract_Name = contract_Name;
	}

	public Date getSigned_Effective_Date() {
		return Signed_Effective_Date;
	}

	public void setSigned_Effective_Date(Date signed_Effective_Date) {
		Signed_Effective_Date = signed_Effective_Date;
	}

	public Date getSow_Strart_Date() {
		return Sow_Strart_Date;
	}

	public void setSow_Strart_Date(Date sow_Strart_Date) {
		Sow_Strart_Date = sow_Strart_Date;
	}

	public Date getSow_End_Date() {
		return Sow_End_Date;
	}

	public void setSow_End_Date(Date sow_End_Date) {
		Sow_End_Date = sow_End_Date;
	}

	public int getTenure() {
		return Tenure;
	}

	public void setTenure(int tenure) {
		Tenure = tenure;
	}

	public String getFG_Id() {
		return FG_Id;
	}

	public void setFG_Id(String fG_Id) {
		FG_Id = fG_Id;
	}

	public String getSource_Data() {
		return Source_Data;
	}

	public void setSource_Data(String source_Data) {
		Source_Data = source_Data;
	}

	public String getSow_Status() {
		return Sow_Status;
	}

	public void setSow_Status(String sow_Status) {
		Sow_Status = sow_Status;
	}

	public String getGeography() {
		return Geography;
	}

	public void setGeography(String geography) {
		Geography = geography;
	}

	public String getArea() {
		return Area;
	}

	public void setArea(String area) {
		Area = area;
	}

	public String getCiti_SOWOwner_Name() {
		return Citi_SOWOwner_Name;
	}

	public void setCiti_SOWOwner_Name(String citi_SOWOwner_Name) {
		Citi_SOWOwner_Name = citi_SOWOwner_Name;
	}

	public String getCiti_SOWOwner_Email_Id() {
		return Citi_SOWOwner_Email_Id;
	}

	public void setCiti_SOWOwner_Email_Id(String citi_SOWOwner_Email_Id) {
		Citi_SOWOwner_Email_Id = citi_SOWOwner_Email_Id;
	}

	public String getCiti_PM() {
		return Citi_PM;
	}

	public void setCiti_PM(String citi_PM) {
		Citi_PM = citi_PM;
	}

	public String getCiti_PM_EmailId() {
		return Citi_PM_EmailId;
	}

	public void setCiti_PM_EmailId(String citi_PM_EmailId) {
		Citi_PM_EmailId = citi_PM_EmailId;
	}

	public String getVirtusa_PM_Name() {
		return Virtusa_PM_Name;
	}

	public void setVirtusa_PM_Name(String virtusa_PM_Name) {
		Virtusa_PM_Name = virtusa_PM_Name;
	}

	public String getVirtusa_PM_EmailId() {
		return Virtusa_PM_EmailId;
	}

	public void setVirtusa_PM_EmailId(String virtusa_PM_EmailId) {
		Virtusa_PM_EmailId = virtusa_PM_EmailId;
	}

	public String getAutoemailtriggeredflag() {
		return autoemailtriggeredflag;
	}

	public void setAutoemailtriggeredflag(String autoemailtriggeredflag) {
		this.autoemailtriggeredflag = autoemailtriggeredflag;
	}

	public Date getAutoemailtriggereddate() {
		return autoemailtriggereddate;
	}

	public void setAutoemailtriggereddate(Date autoemailtriggereddate) {
		this.autoemailtriggereddate = autoemailtriggereddate;
	}

	public int getKey_Personnel_SOW_Count() {
		return Key_Personnel_SOW_Count;
	}

	public void setKey_Personnel_SOW_Count(int key_Personnel_SOW_Count) {
		Key_Personnel_SOW_Count = key_Personnel_SOW_Count;
	}

	public String getCOB_Applicability() {
		return COB_Applicability;
	}

	public void setCOB_Applicability(String cOB_Applicability) {
		COB_Applicability = cOB_Applicability;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

	public Date getCreated_Date() {
		return Created_Date;
	}

	public void setCreated_Date(Date created_Date) {
		Created_Date = created_Date;
	}

	public String getCreated_By() {
		return Created_By;
	}

	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}

	public Date getModified_Date() {
		return Modified_Date;
	}

	public void setModified_Date(Date modified_Date) {
		Modified_Date = modified_Date;
	}

	public String getModified_By() {
		return Modified_By;
	}

	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}

	
		
	
	
}
