package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="SowMaster")
public class SowMasterModel {

	@Id
	@Column(name = "SOW_Sequence_Id",nullable = false)
	private int SOW_Sequence_Id;
	
	@Column(name = "Contract_Name",columnDefinition="char(15)",nullable = false)
	private String Contract_Name;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="SOW_Sequence_Id_fk_int",referencedColumnName="SOW_Sequence_Id")
	List<ProjectMasterModel> pmodel = new ArrayList<>();
	
	public SowMasterModel() {
		
	}

	
	public SowMasterModel(int sOW_Sequence_Id, String contract_Name) {
		super();
		SOW_Sequence_Id = sOW_Sequence_Id;
		Contract_Name = contract_Name;
	}


	public int getSOW_Sequence_Id() {
		return SOW_Sequence_Id;
	}

	public void setSOW_Sequence_Id(int sOW_Sequence_Id) {
		SOW_Sequence_Id = sOW_Sequence_Id;
	}

	public String getContract_Name() {
		return Contract_Name;
	}

	public void setContract_Name(String contract_Name) {
		Contract_Name = contract_Name;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}
/*
 	
	@Column(name = "SOW_Contract_Id",columnDefinition="char(100)",nullable = false)
	private String SOW_Contract_Id;
	
	@Column(name = "SOW_Contract_Pred_Id",columnDefinition="char(100)",nullable = false)
	private String SOW_Contract_Pred_Id;
	
	
	@Column(name = "Signed_Effective_Date",nullable = false)
	private Date Signed_Effective_Date;
	
	@Column(name = "Sow_Strart_Date",nullable = false)
	private Date Sow_Strart_Date;
	
	@Column(name = "Sow_End_Date",nullable = false)
	private Date Sow_End_Date;
	
	@Column(name = "Tenure",nullable = false)
	private int Tenure;
	
	@Column(name = "FG_Id",columnDefinition="char(100)",nullable = false)
	private String FG_Id;
	
	
	
	@Column(name = "Source_Data",columnDefinition="char(100)",nullable = false)
	private String Source_Data;
	
	@Column(name = "Sow_Status",columnDefinition="char(100)",nullable = false)
	private String Sow_Status;
		
	@Column(name = "Geography",columnDefinition="char(100)",nullable = false)
	private String Geography;
	
	
	@Column(name = "Area",columnDefinition="char(100)",nullable = false)
	private String Area;
	
	
	@Column(name = "Citi_SOWOwner_Name",columnDefinition="char(100)",nullable = false)
	private String Citi_SOWOwner_Name;
	
	@Column(name = "Citi_SOWOwner_Email_Id",columnDefinition="char(100)",nullable = false)
	private String Citi_SOWOwner_Email_Id;
	
	@Column(name = "Citi_PM",columnDefinition="char(100)",nullable = false)
	private String Citi_PM;
	
	@Column(name = "Citi_PM_EmailId",columnDefinition="char(100)",nullable = false)
	private String Citi_PM_EmailId;
	
	@Column(name = "Virtusa_PM_Name",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PM_Name;
	
	@Column(name = "Virtusa_PM_EmailId",columnDefinition="char(100)",nullable = false)
	private String Virtusa_PM_EmailId;
	
	
	@Column(name = "AutoEmail_TriggerdFlag",columnDefinition="char(100)",nullable = false)
	private String autoemailtriggeredflag;
	
	@Column(name = "AutoEmail_TriggeredDate",nullable = false)
	private Date autoemailtriggereddate;
	
	
    @Column(name = "Key_Personnel_SOW_Count",nullable = false)
	private int Key_Personnel_SOW_Count;
	
	@Column(name = "COB_Applicability",columnDefinition="char(100)",nullable = false)
	private String COB_Applicability;
	
	Column(name = "Remarks",columnDefinition="char(100)",nullable = false)
	private String Remarks;
	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	
	@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	
	
	
	@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
	private String Modified_By;
	
	
	

 */

	
	
	
	
}
