//package com.virtusa.auroraops.models;
package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;
@Entity
@Table(name="ServiceTypeMaster")
public class ServiceTypeModel {
	@Id
	@Column(name = "Service_Type_Id",nullable = false)
	private int Service_Type_Id;
	
	@Column(name = "Servicet_Type_Value",columnDefinition="char(30)",nullable = false)
	private String Service_Type_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Service_Type_Id_fk_int",referencedColumnName="Service_Type_Id")
	List<SowMasterModel> smodel = new ArrayList<>();
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Service_Type_Virtusa_Id_fk",referencedColumnName="Service_Type_Id")
	List<ProjectMasterModel> pmmodel = new ArrayList<>();

	

	public ServiceTypeModel() {
		
	}
	public ServiceTypeModel(int service_Type_Id, String service_Type_Value) {
		super();
		Service_Type_Id = service_Type_Id;
		Service_Type_Value = service_Type_Value;
	}

	public int getService_Type_Id() {
		return Service_Type_Id;
	}

	public void setService_Type_Id(int service_Type_Id) {
		Service_Type_Id = service_Type_Id;
	}

	public String getService_Type_Value() {
		return Service_Type_Value;
	}

	public void setService_Type_Value(String service_Type_Value) {
		Service_Type_Value = service_Type_Value;
	}

	public List<SowMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}
	
	public List<ProjectMasterModel> getPmmodel() {
		return pmmodel;
	}

	public void setPmmodel(List<ProjectMasterModel> smodel) {
		this.pmmodel = pmmodel;
	}

	
	

}
