package com.virtusa.auroraops.dto;
import lombok.ToString;

//@ToString

public class OrderResponse {
	
	/* String Program_Name();
	String Segment_Value();
 String  GDPR();
	 String Process_Template();
	String Area();
	int Revenue();
	int Cost();*/
	
	private String Program_Name;
	private String Segment_Value;
    private String  GDPR;
	 private String Process_Template;
	private String Area;
	private int Revenue;
	private int Cost;
	
	
	public OrderResponse() {
		
	}
	
	public OrderResponse(String program_Name, String segment_Value, String gDPR, String process_Template, String area,
			int revenue, int cost) {
		super();
		Program_Name = program_Name;
		Segment_Value = segment_Value;
		GDPR = gDPR;
		Process_Template = process_Template;
		Area = area;
		Revenue = revenue;
		Cost = cost;
	}
	public String getProgram_Name() {
		return Program_Name;
	}
	public void setProgram_Name(String program_Name) {
		Program_Name = program_Name;
	}
	public String getSegment_Value() {
		return Segment_Value;
	}
	public void setSegment_Value(String segment_Value) {
		Segment_Value = segment_Value;
	}
	public String getGDPR() {
		return GDPR;
	}
	public void setGDPR(String gDPR) {
		GDPR = gDPR;
	}
	public String getProcess_Template() {
		return Process_Template;
	}
	public void setProcess_Template(String process_Template) {
		Process_Template = process_Template;
	}
	public String getArea() {
		return Area;
	}
	public void setArea(String area) {
		Area = area;
	}
	public int getRevenue() {
		return Revenue;
	}
	public void setRevenue(int revenue) {
		Revenue = revenue;
	}
	public int getCost() {
		return Cost;
	}
	public void setCost(int cost) {
		Cost = cost;
	}
	


}
