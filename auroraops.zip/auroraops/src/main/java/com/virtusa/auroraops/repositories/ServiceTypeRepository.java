package com.virtusa.auroraops.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.virtusa.auroraops.models.ServiceTypeModel;
@Repository
public interface ServiceTypeRepository extends JpaRepository<ServiceTypeModel,Integer> {

}
