package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="BusinessMaster")
public class BusinessMasterModel {
	@Id
	@Column(name = "Aurora_Business_Unit_Seq",nullable = false)
	private int Aurora_Business_Unit_Seq;
	
	@Column(name = "Business_Unit_Value",columnDefinition="char(30)",nullable = false)
	private String Business_Unit_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Aurora_Business_Unit_Seq_fk_int",referencedColumnName="Aurora_Business_Unit_Seq")
	List<SowMasterModel> smodel = new ArrayList<>();
	
	
	public BusinessMasterModel() {
		
	}



	public BusinessMasterModel(int aurora_Business_Unit_Seq, String business_Unit_Value, List<SowMasterModel> smodel) {
		super();
		Aurora_Business_Unit_Seq = aurora_Business_Unit_Seq;
		Business_Unit_Value = business_Unit_Value;
		this.smodel = smodel;
	}



	public int getAurora_Business_Unit_Seq() {
		return Aurora_Business_Unit_Seq;
	}


	public void setAurora_Business_Unit_Seq(int aurora_Business_Unit_Seq) {
		Aurora_Business_Unit_Seq = aurora_Business_Unit_Seq;
	}


	public String getBusiness_Unit_Value() {
		return Business_Unit_Value;
	}


	public void setBusiness_Unit_Value(String business_Unit_Value) {
		Business_Unit_Value = business_Unit_Value;
	}


	public List<SowMasterModel> getSmodel() {
		return smodel;
	}


	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}
	
	
		

}
