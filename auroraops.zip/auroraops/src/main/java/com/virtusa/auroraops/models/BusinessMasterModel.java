package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="BusinessMaster")
public class BusinessMasterModel {
	@Id
	@Column(name = "Business_Unit_Id",nullable = false)
	private int Business_Unit_Id;
	
	@Column(name = "Business_Unit_Value",columnDefinition="char(30)",nullable = false)
	private String Business_Unit_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Business_Unit_Id_fk_int",referencedColumnName="Business_Unit_Id")
	List<SowMasterModel> smodel = new ArrayList<>();
	
	
	public BusinessMasterModel() {
		
	}
	
	
	public BusinessMasterModel(int business_Unit_Id, String business_Unit_Value) {
		super();
		Business_Unit_Id = business_Unit_Id;
		Business_Unit_Value = business_Unit_Value;
	}


	public int getBusiness_Unit_Id() {
		return Business_Unit_Id;
	}
	public void setBusiness_Unit_Id(int business_Unit_Id) {
		Business_Unit_Id = business_Unit_Id;
	}
	public String getBusiness_Unit_Value() {
		return Business_Unit_Value;
	}
	public void setBusiness_Unit_Value(String business_Unit_Value) {
		Business_Unit_Value = business_Unit_Value;
	}
	public List<SowMasterModel> getSmodel() {
		return smodel;
	}
	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}
	

}
