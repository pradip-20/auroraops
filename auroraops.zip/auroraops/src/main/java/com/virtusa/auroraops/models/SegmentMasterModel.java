package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="SegmentMaster")
public class SegmentMasterModel {
	@Id
	@Column(name = "Segment_Id",nullable = false)
	private int Segment_Id;
	
	@Column(name = "Segment_Value",columnDefinition="char(30)",nullable = false)
	private String Segment_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Segment_Id_fk_int",referencedColumnName="Segment_Id")
	List<ProjectMasterModel> pmodel = new ArrayList<>();
	public SegmentMasterModel() {
		
	}
	

	
	public SegmentMasterModel(int segment_Id, String segment_Value) {
		super();
		Segment_Id = segment_Id;
		Segment_Value = segment_Value;
	}



	public int getSegment_Id() {
		return Segment_Id;
	}

	public void setSegment_Id(int segment_Id) {
		Segment_Id = segment_Id;
	}

	public String getSegment_Value() {
		return Segment_Value;
	}

	public void setSegment_Value(String segment_Value) {
		Segment_Value = segment_Value;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}
	

}
