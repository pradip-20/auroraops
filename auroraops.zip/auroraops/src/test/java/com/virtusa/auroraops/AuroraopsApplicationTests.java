package com.virtusa.auroraops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuroraopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
