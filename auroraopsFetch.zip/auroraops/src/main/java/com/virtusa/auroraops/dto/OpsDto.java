package com.virtusa.auroraops.dto;

import java.math.BigDecimal;
import java.sql.Date;

public interface OpsDto {
	
	String getSegmentName();
	Integer getChorusCode();
	String getChorusProjectName();
	String getVelocityProjectCode();
	String getProcess_Template();
	String getContractName();
	Date getVelocity_Start_Date();
	Date getVelocity_End_Date();
	String getProject_Health();
	String getVirtusa_PM_Name();
	String getVirtusa_PD_Name();
	String getVirtusa_DD_Name();
	String getprogram_name();
	Integer getAurora_SOW_Seq();
	Date getSow_Strart_Date();
	Date getSow_End_Date();
	String getSow_Status();
	BigDecimal getSOW_Value();
	BigDecimal getSavings_RFP();
	BigDecimal getEIP_Value();
	String getResource_Onboarding_Delay();
	Integer getChurn_Attrition_Count();
	Integer getChurn_Excused_Count();
	String getGDPR();
	String getArea();
	Integer getRevenue();
	Integer getRetention_Issue();
	
	Integer getContractor_Cost();
	Integer getContractor_Count();
	BigDecimal getCost_Of_Hiring();
	Integer getCost();
	Integer getCost_Tier0();
	Integer getCost_Tier1();
	Integer getCost_Tier2();
	Integer getCost_Tier3();
	//Integer getCost_Tier4();
	BigDecimal getFTE_Tier0();
	BigDecimal getFTE_Tier1();
	BigDecimal getFTE_Tier2();
	BigDecimal getFTE_Tier3();
	BigDecimal getOffshore_FTE_Tier0();
	BigDecimal getOffshore_FTE_Tier1();
	BigDecimal getOffshore_FTE_Tier2();
	BigDecimal getOffshore_FTE_Tier3();
	Integer getOffshore_R_Cost_Tier0();
	Integer getOffshore_R_Cost_Tier1();
	Integer getOffshore_R_Cost_Tier2();
	Integer getOffshore_R_Cost_Tier3();
	BigDecimal getOnsite_FTE_Tier0();
	BigDecimal getOnsite_FTE_Tier1();
	BigDecimal getOnsite_FTE_Tier2();
	BigDecimal getOnsite_FTE_Tier3();
	Integer getOnsite_R_Cost_Tier0();
	Integer getOnsite_R_Cost_Tier1();
	Integer getOnsite_R_Cost_Tier2();
	Integer getOnsite_R_Cost_Tier3();
	Integer getInternal_Fulfillments_Number();
	Integer getExternal_Fulfillments_Number();
	Integer getInterviews_Held_Number();
	Integer getClient_Rejections_Number();
	BigDecimal getMargin();
	BigDecimal getDMI_Score();
	 Integer getPast_Due_RRs();
	 Integer getAgeing_Of_PastDue_RRs();
	
	
	


}
