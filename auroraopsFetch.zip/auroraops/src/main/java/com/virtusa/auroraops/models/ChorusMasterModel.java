package com.virtusa.auroraops.models;
import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ChorusMaster")
public class ChorusMasterModel {
	
	@Id
	@Column(name = "Chorus_Code",nullable = false)
	private int Chorus_Code;

	@Column(name = "Chorus_Project_Name",columnDefinition="char(15)",nullable = false)
	private String Chorus_Project_Name;
	
	@Column(name = "Chorus_Start_Date",nullable = false)
	private Date Chorus_Start_Date;
	
	@Column(name = "Chorus_End_Date",nullable = false)
	private Date Chorus_End_Date;
	
	@Column(name = "Process_Template",columnDefinition="char(15)",nullable = false)
	private String Process_Template;
	
	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	
	@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	
	@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
	private String Modified_By;
	
	
	
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL,mappedBy="cmodel")
	//@JoinColumn(name="cid_fk")
	private  ProjectLeadingModel projectLeadingModel;
	
    //@ManyToOne
	
	public ChorusMasterModel() {
		
	}
	

		
	
	/*
	 
	
	 */
	
	
	

}
