package com.virtusa.auroraops.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.auroraops.dto.OpsDto;
//import com.virtusa.auroraops.dto.OrderResponse;
//import com.virtusa.auroraops.models.OrderResponse;
import com.virtusa.auroraops.models.SegmentMasterModel;
@Repository
public interface SegmentMasterRepository extends JpaRepository<SegmentMasterModel,Integer>{

	
/*@Query(value="select com.virtusa.auroraops.dto.OrderResponse(s.Segment_Value,r.Program_Name,p.GDPR,c.Process_Template, q.Area,l.Revenue,l.Cost) from SegmentMaster s inner join ProjectMaster p on\r\n" + 
			"s.Aurora_Segment_Seq=p.Aurora_Segment_Seq_fk_int inner join ProgramMaster r on\r\n" + 
			"p.Aurora_Program_Seq_fk=r.Aurora_Program_Seq  inner join ChorusMaster c  on\r\n" + 
			"p. Aurora_Project_Seq=c.Aurora_Project_Seq_fk_int inner join SowMaster q on\r\n" + 
			"q.Aurora_SOW_Seq=p.Aurora_SOW_Seq_fk_int inner join ProjectLeadMaster l on\r\n" + 
			"c.Chorus_Code=l.Course_Code_fk;",nativeQuery=true)*/
	

	
	@Query(value="select s.Segment_Value as SegmentName,c.Chorus_Code as ChorusCode,c.Chorus_Project_Name as ChorusProjectName,"
			+ "p.Velocity_ProjectCode as VelocityProjectCode,q.Aurora_SOW_Seq,"
			+ "q.Sow_Status,q.Sow_End_Date,q.Sow_Strart_Date,l.Resource_Onboarding_Delay"
			+ ",l.Savings_RFP,l.Margin,l.Cost_Of_Hiring,l.Internal_Fulfillments_Number,l.External_Fulfillments_Number,l.Interviews_Held_Number,l.Client_Rejections_Number,l.DMI_Score,l.Contractor_Count,l.Contractor_Cost,l.Past_Due_RRs,l.Ageing_Of_PastDue_RRs,l.Retention_Issue,l.Onsite_R_Cost_Tier0,l.Onsite_R_Cost_Tier1,l.Onsite_R_Cost_Tier2,l.Onsite_R_Cost_Tier3,l.Onsite_FTE_Tier0,l.Onsite_FTE_Tier1,l.Onsite_FTE_Tier2,l.Onsite_FTE_Tier3,l.Offshore_R_Cost_Tier0,"
			+ "l.Offshore_R_Cost_Tier1,l.Offshore_R_Cost_Tier2,l.Offshore_R_Cost_Tier3,l.Offshore_FTE_Tier0,"
			+ "l.Offshore_FTE_Tier1,l.Offshore_FTE_Tier2,l.Offshore_FTE_Tier3,l.FTE_Tier0,l.FTE_Tier1,l.FTE_Tier2,l.FTE_Tier3,l.Cost_Tier0,"
			+ "l.Cost_Tier1,l.Cost_Tier2,l.Cost_Tier3,l.EIP_Value,"
			+ "l.Churn_Attrition_Count,"
			+ "l.Cost,l.Churn_Excused_Count,l.SOW_Value,l.Project_Health,"
			+ "p.Virtusa_DD_Name,p.Virtusa_PD_Name,p.Virtusa_PM_Name,q.Contract_Name as ContractName,"
			+ "p.Velocity_Start_Date,p.Velocity_End_Date,r.program_name,p.gdpr,c.Process_Template, "
			+ "q.area,l.Revenue,l.cost from segmentmaster s inner join projectmaster p on\r\n" + 
			"s.Aurora_Segment_Seq=p.Aurora_Segment_Seq_fk_int inner join programmaster r on\r\n" + 
			"p.Aurora_Program_Seq_fk=r.Aurora_Program_Seq  inner join chorusmaster c  on\r\n" + 
			"p. Aurora_Project_Seq=c.Aurora_Project_Seq_fk_int inner join sowmaster q on\r\n" + 
			"q.Aurora_SOW_Seq=p.Aurora_SOW_Seq_fk_int inner join projectleadmaster l on\r\n" + 
			"c.Chorus_Code=l.Course_Code_fk;\r\n" + 
			"",nativeQuery=true)
	
	public List<OpsDto> getJoinInformation();
}
