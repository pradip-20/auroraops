package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ProjectMaster")

public class ProjectMasterModel {
	@Id
	@Column(name = "Aurora_Project_Seq",nullable = false)
	private int Aurora_Project_Seq;
	
	 @Column(name = "Velocity_ProjectCode",columnDefinition="char(100)",nullable = false)
     private String Velocity_ProjectCode;
	 
	  @Column(name = "Project_Name",columnDefinition="char(100)",nullable = false)
	  private String Project_Name;
	 	
	  @Column(name = "Project_Status",columnDefinition="char(100)",nullable = false)
	  private String Project_Status;
	  
	  @Column(name = "Resources_Currently_Allocated",columnDefinition="char(1)",nullable = false)
	 private String Resources_Currently_Allocated;
	  
	  @Column(name = "Velocity_Start_Date",nullable = false)
		private Date Velocity_Start_Date;
		
		@Column(name = "Velocity_End_Date",nullable = false)
		private Date Velocity_End_Date;
		
		@Column(name = "Virtusa_Segment_DeliveryHead",columnDefinition="char(100)",nullable = false)
		private String Virtusa_Segment_DeliveryHead;

		@Column(name = "Virtusa_DD_Name",columnDefinition="char(100)",nullable = false)
		private String Virtusa_DD_Name;
		
		@Column(name = "Virtusa_DD_EmailId",columnDefinition="char(100)",nullable = false)
		private String Virtusa_DD_EmailId;
		
		@Column(name = "Virtusa_PD_Name",columnDefinition="char(100)",nullable = false)
		private String Virtusa_PD_Name;
		
		@Column(name = "Virtusa_PD_EmailId",columnDefinition="char(100)",nullable = false)
		private String Virtusa_PD_EmailId;
		
		@Column(name = "Virtusa_PM_Name",columnDefinition="char(100)",nullable = false)
		private String Virtusa_PM_Name;
		
		@Column(name = "Virtusa_PM_EmailId",columnDefinition="char(100)",nullable = false)
		private String Virtusa_PM_EmailId;
		
		@Column(name = "IT_Cluster",columnDefinition="char(100)",nullable = false)
		private String IT_Cluster;

	    @Column(name = "Total_HC",nullable = false)
	    private int Total_HC;
			
		 @Column(name = "HC_On",nullable = false)
		private int HC_On;
			
	    @Column(name = "HC_Off",nullable = false)
	    private int HC_Off;
		
		@Column(name = "Recovery_Time_Objective",columnDefinition="char(100)",nullable = false)
		private String Recovery_Time_Objective;
	    @Column(name = "Engagement_Plan_Applicability",columnDefinition="char(100)",nullable = false)
		private String Engagement_Plan_Applicability;
				
		@Column(name = "Engagement_Plan_Exemption_Reason",columnDefinition="char(100)",nullable = false)
	    private String Engagement_Plan_Exemption_Reason;
				
		@Column(name = "SLA_Applicability",columnDefinition="char(100)",nullable = false)
		private String SLA_Applicability;
				
	    @Column(name = "KPI_Applicability",columnDefinition="char(100)",nullable = false)
		private String KPI_Applicability;
				
		@Column(name = "Key_Personnel_Including_PM",nullable = false)
		private int Key_Personnel_Including_PM;
				
		@Column(name = "Project_Life_Cycle",columnDefinition="char(100)",nullable = false)
	    private String Project_Life_Cycle;
					
		@Column(name = "Project_Applicability_Secure_SDLC",columnDefinition="char(100)",nullable = false)
	     private String Project_Applicability_Secure_SDLC;
 
         @Column(name = "Project_Mobile_Development_Component",columnDefinition="char(100)",nullable = false)
		private String Project_Mobile_Development_Component;

		@Column(name = "Release_Notes_Applicability",columnDefinition="char(100)",nullable = false)
		private String Release_Notes_Applicability;
					
		@Column(name = "Self_Assessment_Applicability",columnDefinition="char(100)",nullable = false)
		private String Self_Assessment_Applicability;
					
		@Column(name = "Governance_Report_Applicability",columnDefinition="char(100)",nullable = false)
		private String Governance_Report_Applicability;
					
		@Column(name = "Governance_Report_Frequency",columnDefinition="char(100)",nullable = false)
		private String Governance_Report_Frequency;
					
		@Column(name = "GDPR",columnDefinition="char(100)",nullable = false)
		private String GDPR;
					
	   @Column(name = "Remarks",columnDefinition="char(100)",nullable = false)
		private String Remarks;
		@Column(name = "Highest_Confidentiality",columnDefinition="char(100)",nullable = false)
		private String Highest_Confidentiality;
					
		@Column(name = "Created_Date",nullable = false)
	    private Date Created_Date;
		
		@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
		private String Created_By;
					
	    @Column(name = "Modified_Date",nullable = false)
		private Date Modified_Date;
	    
		@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
		private String Modified_By;
					
					
					
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Aurora_Project_Seq_fk_int",referencedColumnName="Aurora_Project_Seq",nullable=false)
	List<ChorusMasterModel> cmodel = new ArrayList<>();
	
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Aurora_Project_Seq_fk_int",referencedColumnName="Aurora_Project_Seq",nullable=false)
	List<ResourcesMasterModel> resourceMasterModel = new ArrayList<>();
		
	
	public ProjectMasterModel()
	{
		
	}
	
	


	public ProjectMasterModel(int aurora_Project_Seq, String velocity_ProjectCode, String project_Name,
			String project_Status, String resources_Currently_Allocated, Date velocity_Start_Date,
			Date velocity_End_Date, String virtusa_Segment_DeliveryHead, String virtusa_DD_Name,
			String virtusa_DD_EmailId, String virtusa_PD_Name, String virtusa_PD_EmailId, String virtusa_PM_Name,
			String virtusa_PM_EmailId, String iT_Cluster, int total_HC, int hC_On, int hC_Off,
			String recovery_Time_Objective, String engagement_Plan_Applicability,
			String engagement_Plan_Exemption_Reason, String sLA_Applicability, String kPI_Applicability,
			int key_Personnel_Including_PM, String project_Life_Cycle, String project_Applicability_Secure_SDLC,
			String project_Mobile_Development_Component, String release_Notes_Applicability,
			String self_Assessment_Applicability, String governance_Report_Applicability,
			String governance_Report_Frequency, String gDPR, String remarks, String highest_Confidentiality,
			Date created_Date, String created_By, Date modified_Date, String modified_By,
			List<ChorusMasterModel> cmodel, List<ResourcesMasterModel> resourceMasterModel) {
		super();
		Aurora_Project_Seq = aurora_Project_Seq;
		Velocity_ProjectCode = velocity_ProjectCode;
		Project_Name = project_Name;
		Project_Status = project_Status;
		Resources_Currently_Allocated = resources_Currently_Allocated;
		Velocity_Start_Date = velocity_Start_Date;
		Velocity_End_Date = velocity_End_Date;
		Virtusa_Segment_DeliveryHead = virtusa_Segment_DeliveryHead;
		Virtusa_DD_Name = virtusa_DD_Name;
		Virtusa_DD_EmailId = virtusa_DD_EmailId;
		Virtusa_PD_Name = virtusa_PD_Name;
		Virtusa_PD_EmailId = virtusa_PD_EmailId;
		Virtusa_PM_Name = virtusa_PM_Name;
		Virtusa_PM_EmailId = virtusa_PM_EmailId;
		IT_Cluster = iT_Cluster;
		Total_HC = total_HC;
		HC_On = hC_On;
		HC_Off = hC_Off;
		Recovery_Time_Objective = recovery_Time_Objective;
		Engagement_Plan_Applicability = engagement_Plan_Applicability;
		Engagement_Plan_Exemption_Reason = engagement_Plan_Exemption_Reason;
		SLA_Applicability = sLA_Applicability;
		KPI_Applicability = kPI_Applicability;
		Key_Personnel_Including_PM = key_Personnel_Including_PM;
		Project_Life_Cycle = project_Life_Cycle;
		Project_Applicability_Secure_SDLC = project_Applicability_Secure_SDLC;
		Project_Mobile_Development_Component = project_Mobile_Development_Component;
		Release_Notes_Applicability = release_Notes_Applicability;
		Self_Assessment_Applicability = self_Assessment_Applicability;
		Governance_Report_Applicability = governance_Report_Applicability;
		Governance_Report_Frequency = governance_Report_Frequency;
		GDPR = gDPR;
		Remarks = remarks;
		Highest_Confidentiality = highest_Confidentiality;
		Created_Date = created_Date;
		Created_By = created_By;
		Modified_Date = modified_Date;
		Modified_By = modified_By;
		this.cmodel = cmodel;
		this.resourceMasterModel = resourceMasterModel;
	}




	public int getAurora_Project_Seq() {
		return Aurora_Project_Seq;
	}


	public void setAurora_Project_Seq(int aurora_Project_Seq) {
		Aurora_Project_Seq = aurora_Project_Seq;
	}


	public String getVelocity_ProjectCode() {
		return Velocity_ProjectCode;
	}


	public void setVelocity_ProjectCode(String velocity_ProjectCode) {
		Velocity_ProjectCode = velocity_ProjectCode;
	}


	public String getProject_Name() {
		return Project_Name;
	}


	public void setProject_Name(String project_Name) {
		Project_Name = project_Name;
	}


	public String getProject_Status() {
		return Project_Status;
	}


	public void setProject_Status(String project_Status) {
		Project_Status = project_Status;
	}


	public String getResources_Currently_Allocated() {
		return Resources_Currently_Allocated;
	}


	public void setResources_Currently_Allocated(String resources_Currently_Allocated) {
		Resources_Currently_Allocated = resources_Currently_Allocated;
	}


	public Date getVelocity_Start_Date() {
		return Velocity_Start_Date;
	}


	public void setVelocity_Start_Date(Date velocity_Start_Date) {
		Velocity_Start_Date = velocity_Start_Date;
	}


	public Date getVelocity_End_Date() {
		return Velocity_End_Date;
	}


	public void setVelocity_End_Date(Date velocity_End_Date) {
		Velocity_End_Date = velocity_End_Date;
	}


	public String getVirtusa_Segment_DeliveryHead() {
		return Virtusa_Segment_DeliveryHead;
	}


	public void setVirtusa_Segment_DeliveryHead(String virtusa_Segment_DeliveryHead) {
		Virtusa_Segment_DeliveryHead = virtusa_Segment_DeliveryHead;
	}


	public String getVirtusa_DD_Name() {
		return Virtusa_DD_Name;
	}


	public void setVirtusa_DD_Name(String virtusa_DD_Name) {
		Virtusa_DD_Name = virtusa_DD_Name;
	}


	public String getVirtusa_DD_EmailId() {
		return Virtusa_DD_EmailId;
	}


	public void setVirtusa_DD_EmailId(String virtusa_DD_EmailId) {
		Virtusa_DD_EmailId = virtusa_DD_EmailId;
	}


	public String getVirtusa_PD_Name() {
		return Virtusa_PD_Name;
	}


	public void setVirtusa_PD_Name(String virtusa_PD_Name) {
		Virtusa_PD_Name = virtusa_PD_Name;
	}


	public String getVirtusa_PD_EmailId() {
		return Virtusa_PD_EmailId;
	}


	public void setVirtusa_PD_EmailId(String virtusa_PD_EmailId) {
		Virtusa_PD_EmailId = virtusa_PD_EmailId;
	}


	public String getVirtusa_PM_Name() {
		return Virtusa_PM_Name;
	}


	public void setVirtusa_PM_Name(String virtusa_PM_Name) {
		Virtusa_PM_Name = virtusa_PM_Name;
	}


	public String getVirtusa_PM_EmailId() {
		return Virtusa_PM_EmailId;
	}


	public void setVirtusa_PM_EmailId(String virtusa_PM_EmailId) {
		Virtusa_PM_EmailId = virtusa_PM_EmailId;
	}


	public String getIT_Cluster() {
		return IT_Cluster;
	}


	public void setIT_Cluster(String iT_Cluster) {
		IT_Cluster = iT_Cluster;
	}


	public int getTotal_HC() {
		return Total_HC;
	}


	public void setTotal_HC(int total_HC) {
		Total_HC = total_HC;
	}


	public int getHC_On() {
		return HC_On;
	}


	public void setHC_On(int hC_On) {
		HC_On = hC_On;
	}


	public int getHC_Off() {
		return HC_Off;
	}


	public void setHC_Off(int hC_Off) {
		HC_Off = hC_Off;
	}


	public String getRecovery_Time_Objective() {
		return Recovery_Time_Objective;
	}


	public void setRecovery_Time_Objective(String recovery_Time_Objective) {
		Recovery_Time_Objective = recovery_Time_Objective;
	}


	public String getEngagement_Plan_Applicability() {
		return Engagement_Plan_Applicability;
	}


	public void setEngagement_Plan_Applicability(String engagement_Plan_Applicability) {
		Engagement_Plan_Applicability = engagement_Plan_Applicability;
	}


	public String getEngagement_Plan_Exemption_Reason() {
		return Engagement_Plan_Exemption_Reason;
	}


	public void setEngagement_Plan_Exemption_Reason(String engagement_Plan_Exemption_Reason) {
		Engagement_Plan_Exemption_Reason = engagement_Plan_Exemption_Reason;
	}


	public String getSLA_Applicability() {
		return SLA_Applicability;
	}


	public void setSLA_Applicability(String sLA_Applicability) {
		SLA_Applicability = sLA_Applicability;
	}


	public String getKPI_Applicability() {
		return KPI_Applicability;
	}


	public void setKPI_Applicability(String kPI_Applicability) {
		KPI_Applicability = kPI_Applicability;
	}


	public int getKey_Personnel_Including_PM() {
		return Key_Personnel_Including_PM;
	}


	public void setKey_Personnel_Including_PM(int key_Personnel_Including_PM) {
		Key_Personnel_Including_PM = key_Personnel_Including_PM;
	}


	public String getProject_Life_Cycle() {
		return Project_Life_Cycle;
	}


	public void setProject_Life_Cycle(String project_Life_Cycle) {
		Project_Life_Cycle = project_Life_Cycle;
	}


	public String getProject_Applicability_Secure_SDLC() {
		return Project_Applicability_Secure_SDLC;
	}


	public void setProject_Applicability_Secure_SDLC(String project_Applicability_Secure_SDLC) {
		Project_Applicability_Secure_SDLC = project_Applicability_Secure_SDLC;
	}


	public String getProject_Mobile_Development_Component() {
		return Project_Mobile_Development_Component;
	}


	public void setProject_Mobile_Development_Component(String project_Mobile_Development_Component) {
		Project_Mobile_Development_Component = project_Mobile_Development_Component;
	}


	public String getRelease_Notes_Applicability() {
		return Release_Notes_Applicability;
	}


	public void setRelease_Notes_Applicability(String release_Notes_Applicability) {
		Release_Notes_Applicability = release_Notes_Applicability;
	}


	public String getSelf_Assessment_Applicability() {
		return Self_Assessment_Applicability;
	}


	public void setSelf_Assessment_Applicability(String self_Assessment_Applicability) {
		Self_Assessment_Applicability = self_Assessment_Applicability;
	}


	public String getGovernance_Report_Applicability() {
		return Governance_Report_Applicability;
	}


	public void setGovernance_Report_Applicability(String governance_Report_Applicability) {
		Governance_Report_Applicability = governance_Report_Applicability;
	}


	public String getGovernance_Report_Frequency() {
		return Governance_Report_Frequency;
	}


	public void setGovernance_Report_Frequency(String governance_Report_Frequency) {
		Governance_Report_Frequency = governance_Report_Frequency;
	}


	public String getGDPR() {
		return GDPR;
	}


	public void setGDPR(String gDPR) {
		GDPR = gDPR;
	}


	public String getRemarks() {
		return Remarks;
	}


	public void setRemarks(String remarks) {
		Remarks = remarks;
	}


	public String getHighest_Confidentiality() {
		return Highest_Confidentiality;
	}


	public void setHighest_Confidentiality(String highest_Confidentiality) {
		Highest_Confidentiality = highest_Confidentiality;
	}


	public Date getCreated_Date() {
		return Created_Date;
	}


	public void setCreated_Date(Date created_Date) {
		Created_Date = created_Date;
	}


	public String getCreated_By() {
		return Created_By;
	}


	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}


	public Date getModified_Date() {
		return Modified_Date;
	}


	public void setModified_Date(Date modified_Date) {
		Modified_Date = modified_Date;
	}


	public String getModified_By() {
		return Modified_By;
	}


	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}


	public List<ChorusMasterModel> getCmodel() {
		return cmodel;
	}


	public void setCmodel(List<ChorusMasterModel> cmodel) {
		this.cmodel = cmodel;
	}


	public List<ResourcesMasterModel> getResourceMasterModel() {
		return resourceMasterModel;
	}


	public void setResourceMasterModel(List<ResourcesMasterModel> resourceMasterModel) {
		this.resourceMasterModel = resourceMasterModel;
	}
	


	
		
	

 
}
